tar -czf project.tar.gz \
  --exclude './pico-sdk' \
  --exclude '.DS_Store' \
  --exclude './project.tar.gz' \
  .