#!/bin/bash -
cp ~/het68/build/pico_6mic_soundcard.uf2 /media/fedurca/RP2350/
