#!/usr/bin/env bash
# build.sh — loguje vše do err_build.log (přepisuje se při každém běhu)

set -Eeuo pipefail
# zapni trasování příkazů (aby se logovaly i samotné příkazy)
set -x

# přesměrování veškerého STDOUT/STDERR do logu i na obrazovku (bez appendu)
exec > >(tee err_build.log) 2>&1

# vlastní build
rm -rf build
cmake -S . -B build -DPICO_BOARD="${PICO_BOARD:-pico2}"   # pro Pico 2 W dej PICO_BOARD=pico2_w
cmake --build build -j

