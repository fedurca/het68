sudo lsusb -v -d cafe:4066 &> lsusb_output.txt


