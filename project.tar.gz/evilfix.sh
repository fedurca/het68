git add . && git commit -m "$(date)" && git push --force origin main

