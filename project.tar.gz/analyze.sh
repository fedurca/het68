#!/bin/bash

{
    echo "========================================"
    echo "Čas: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "--- dmesg (posledních 10 řádků) ---"
    dmesg -T | tail -n10
    echo "--- arecord -l ---"
    arecord -l
    echo ""
} >> connect.log 2>&1
